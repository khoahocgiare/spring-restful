package com.example.jobhunter.util.constant;

public enum LevelEnum {
  INTERN, FRESHER, JUNIOR, MIDDLE, SENIOR
}
