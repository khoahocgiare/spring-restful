package com.example.jobhunter.model.request;

import lombok.Data;

@Data
public class ReqLoginDTO {
  private String username;
  private String password;

}
