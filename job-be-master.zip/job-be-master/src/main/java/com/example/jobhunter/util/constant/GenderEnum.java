package com.example.jobhunter.util.constant;

public enum GenderEnum {
  FEMALE, MALE, OTHER
}
